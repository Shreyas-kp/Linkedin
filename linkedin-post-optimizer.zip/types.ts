export type PostGoal = 'Share Achievement' | 'Share Article' | 'Ask Question' | 'Promote Event' | 'Job Search Update';

export type PostTone = 'Professional' | 'Inspirational' | 'Casual' | 'Technical' | 'Humorous';

export interface StyleLibraryItem {
  text: string;
  embedding: number[];
}

export interface PostGenerationParams {
  goal: PostGoal;
  details: string;
  tone: PostTone;
  relevantPosts?: string[];
}

export interface GeneratedPostData {
  title: string;
  content: string;
}

export interface PostAnalysisParams {
  draft: string;
}

export interface DetailedAnalysis {
  hookEffectiveness: string;
  ctaClarity: string;
  readability: string;
  keywordRelevance: string;
}

export interface PostAnalysisData {
  score: number;
  strengths: string[];
  improvements: string[];
  revisedPost: string;
  detailedAnalysis: DetailedAnalysis;
}