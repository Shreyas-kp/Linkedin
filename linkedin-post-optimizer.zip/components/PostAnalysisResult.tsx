import React from 'react';
import { PostAnalysisData } from '../types';
import GeneratedPost from './GeneratedPost';
import { ThumbsUpIcon } from './icons/ThumbsUpIcon';
import { LightbulbIcon } from './icons/LightbulbIcon';
import { HookIcon } from './icons/HookIcon';
import { MegaphoneIcon } from './icons/MegaphoneIcon';
import { BookOpenIcon } from './icons/BookOpenIcon';
import { TagIcon } from './icons/TagIcon';

interface PostAnalysisResultProps {
  result: PostAnalysisData;
}

const ScoreGauge: React.FC<{ score: number }> = ({ score }) => {
    const circumference = 2 * Math.PI * 52;
    const offset = circumference - (score / 100) * circumference;
    
    let colorClass = 'text-green-500';
    if (score < 50) colorClass = 'text-red-500';
    else if (score < 75) colorClass = 'text-yellow-500';

    return (
        <div className="relative flex items-center justify-center h-40 w-40">
            <svg className="transform -rotate-90" width="160" height="160">
                <circle
                    className="text-gray-200"
                    strokeWidth="12"
                    stroke="currentColor"
                    fill="transparent"
                    r="52"
                    cx="80"
                    cy="80"
                />
                <circle
                    className={colorClass}
                    strokeWidth="12"
                    strokeDasharray={circumference}
                    strokeDashoffset={offset}
                    strokeLinecap="round"
                    stroke="currentColor"
                    fill="transparent"
                    r="52"
                    cx="80"
                    cy="80"
                    style={{ transition: 'stroke-dashoffset 0.8s ease-out' }}
                />
            </svg>
            <div className="absolute flex flex-col items-center">
                 <span className={`text-4xl font-bold ${colorClass}`}>{score}</span>
                 <span className="text-xs text-gray-500">SCORE</span>
            </div>
        </div>
    )
}

const DetailedAnalysisCard: React.FC<{ icon: React.ReactNode; title: string; text: string }> = ({ icon, title, text }) => (
  <div className="bg-white p-4 rounded-lg border border-gray-200 flex items-start space-x-4">
    <div className="flex-shrink-0 mt-1">{icon}</div>
    <div>
      <h5 className="font-semibold text-gray-800">{title}</h5>
      <p className="text-sm text-gray-600">{text}</p>
    </div>
  </div>
);

const PostAnalysisResult: React.FC<PostAnalysisResultProps> = ({ result }) => {
  return (
    <div className="space-y-8">
      <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 flex flex-col md:flex-row items-center gap-6">
        <div className="flex-shrink-0">
            <ScoreGauge score={result.score} />
        </div>
        <div className="w-full">
            <h3 className="text-xl font-bold text-gray-800 mb-2">Engagement Potential</h3>
            <p className="text-gray-600">This score estimates your post's potential to attract engagement (likes, comments, shares) based on common best practices for LinkedIn.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-green-50/50 p-5 rounded-xl border border-green-200">
            <h4 className="font-semibold text-lg text-green-800 flex items-center mb-3">
                <ThumbsUpIcon className="h-5 w-5 mr-2" />
                Strengths
            </h4>
            <ul className="space-y-2 list-disc list-inside text-green-700">
                {result.strengths.map((item, i) => <li key={i}>{item}</li>)}
            </ul>
        </div>
        <div className="bg-yellow-50/50 p-5 rounded-xl border border-yellow-200">
            <h4 className="font-semibold text-lg text-yellow-800 flex items-center mb-3">
                <LightbulbIcon className="h-5 w-5 mr-2" />
                Areas for Improvement
            </h4>
            <ul className="space-y-2 list-disc list-inside text-yellow-700">
                {result.improvements.map((item, i) => <li key={i}>{item}</li>)}
            </ul>
        </div>
      </div>

      <div>
        <h4 className="font-semibold text-lg text-gray-800 text-center mb-4">Detailed Breakdown</h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <DetailedAnalysisCard
            icon={<HookIcon className="h-6 w-6 text-blue-600" />}
            title="Hook Effectiveness"
            text={result.detailedAnalysis.hookEffectiveness}
          />
          <DetailedAnalysisCard
            icon={<MegaphoneIcon className="h-6 w-6 text-blue-600" />}
            title="Call-to-Action Clarity"
            text={result.detailedAnalysis.ctaClarity}
          />
          <DetailedAnalysisCard
            icon={<BookOpenIcon className="h-6 w-6 text-blue-600" />}
            title="Readability"
            text={result.detailedAnalysis.readability}
          />
          <DetailedAnalysisCard
            icon={<TagIcon className="h-6 w-6 text-blue-600" />}
            title="Keyword Relevance"
            text={result.detailedAnalysis.keywordRelevance}
          />
        </div>
      </div>
      
      <div>
        <GeneratedPost post={{ title: "AI-Revised Version", content: result.revisedPost }} />
      </div>

    </div>
  );
};

export default PostAnalysisResult;