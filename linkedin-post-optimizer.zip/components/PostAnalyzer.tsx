import React, { useState, useCallback } from 'react';
import { analyzeLinkedInPost } from '../services/geminiService';
import { PostAnalysisData } from '../types';

interface PostAnalyzerProps {
  setIsLoading: (isLoading: boolean) => void;
  setError: (error: string | null) => void;
  setAnalysisResult: (result: PostAnalysisData | null) => void;
  isLoading: boolean;
}

const PostAnalyzer: React.FC<PostAnalyzerProps> = ({ setIsLoading, setError, setAnalysisResult, isLoading }) => {
  const [draft, setDraft] = useState('');

  const isFormValid = draft.trim().length > 20;

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isFormValid) return;

    setIsLoading(true);
    setError(null);
    setAnalysisResult(null);

    try {
      const result = await analyzeLinkedInPost({ draft });
      setAnalysisResult(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [draft, isFormValid, setIsLoading, setError, setAnalysisResult]);

  return (
    <form onSubmit={handleSubmit}>
      <div className="mb-6">
        <label htmlFor="draft" className="block text-sm font-medium text-gray-700 mb-2">
          Paste your post draft here for analysis
        </label>
        <textarea
          id="draft"
          name="draft"
          rows={10}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
          placeholder="Crafted a post but not sure if it will land? Paste it here and let our AI coach give you feedback..."
        />
        <p className="text-xs text-gray-500 mt-1">Minimum 20 characters for a meaningful analysis.</p>
      </div>
      <div className="flex justify-end">
        <button
          type="submit"
          disabled={!isFormValid || isLoading}
          className="px-8 py-3 bg-blue-600 text-white font-bold rounded-lg shadow-md hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors duration-300"
        >
          {isLoading ? 'Analyzing...' : 'Analyze Post'}
        </button>
      </div>
    </form>
  );
};

export default PostAnalyzer;
