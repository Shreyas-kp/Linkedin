import { GoogleGenAI, Type } from "@google/genai";
import { PostGenerationParams, GeneratedPostData, PostAnalysisParams, PostAnalysisData } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });
const generativeModel = "gemini-2.5-pro";
const embeddingModel = "text-embedding-004";


export const embedText = async (text: string): Promise<number[]> => {
  try {
    // FIX: The 'embedContent' method expects a 'contents' property, not 'content'.
    const response = await ai.models.embedContent({
      model: embeddingModel,
      contents: text,
    });
    // FIX: The response object contains an 'embeddings' array. We take the first result for a single text embedding.
    return response.embeddings[0].values;
  } catch (error) {
    console.error("Error embedding text:", error);
    throw new Error("Failed to create text embedding for RAG.");
  }
};

export const generateLinkedInPosts = async (params: PostGenerationParams): Promise<GeneratedPostData[]> => {
  const { goal, details, tone, relevantPosts } = params;

  const ragGuidance = (relevantPosts && relevantPosts.length > 0)
    ? `
      **Style Guide (from user's successful posts):**
      To perfectly match the user's personal style, you MUST use the following posts as a style guide.
      Analyze their writing style, voice, tone, and formatting (e.g., use of emojis, hashtags, paragraph structure)
      and apply it to the new posts you generate.

      **Style Examples:**
      ---
      ${relevantPosts.map((post, index) => `Example ${index + 1}:\n${post}`).join('\n---\n')}
      ---
    `
    : '';

  const prompt = `
    You are an expert LinkedIn content strategist and copywriter. Your goal is to help users create highly engaging posts that maximize visibility and interaction.

    A user wants to create a post with the following specifications:
    - **Goal:** ${goal}
    - **Tone:** ${tone}
    - **Core Message/Details:** ${details}

    ${ragGuidance}

    Based on all the information provided, generate 3 distinct variations of a LinkedIn post. If style examples were provided, the posts MUST reflect that style. Each post should be optimized for engagement by including:
    1. A strong hook to grab attention.
    2. Clear and concise body text, using paragraphs and line breaks for readability.
    3. A clear call-to-action (if applicable for the goal).
    4. Relevant and popular hashtags (between 3 to 5).
    5. Appropriate use of emojis to add personality.

    Return the output as a JSON object that matches the provided schema. Each variation should have a descriptive title (e.g., "Concise & Punchy", "Storytelling Approach", "Question-Based Engagement").
  `;

  try {
    const response = await ai.models.generateContent({
      model: generativeModel,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              content: { type: Type.STRING },
            },
            required: ["title", "content"],
          },
        },
      },
    });

    const jsonText = response.text.trim();
    const generatedPosts: GeneratedPostData[] = JSON.parse(jsonText);
    return generatedPosts;
  } catch (error) {
    console.error("Error generating content:", error);
    throw new Error("Failed to generate LinkedIn posts. Please check your input and try again.");
  }
};


export const analyzeLinkedInPost = async (params: PostAnalysisParams): Promise<PostAnalysisData> => {
    const { draft } = params;

    const prompt = `
    You are an expert LinkedIn coach and content strategist. Your task is to analyze a user's draft post and provide actionable feedback.

    **Post Draft to Analyze:**
    ---
    ${draft}
    ---

    Perform a comprehensive analysis and return your feedback as a JSON object matching the provided schema. Your analysis must include:
    1.  **score**: An overall "Engagement Potential" score from 0 to 100.
    2.  **strengths**: A list of 2-3 bullet points highlighting what the post does well (e.g., "Strong opening hook," "Clear value proposition").
    3.  **improvements**: A list of 2-3 specific, actionable areas for improvement (e.g., "Add a direct question to encourage comments," "Break down the large paragraph for better readability").
    4.  **revisedPost**: A completely rewritten version of the post that incorporates your feedback for maximum impact and engagement.
    5.  **detailedAnalysis**: A granular breakdown of specific post elements:
        *   **hookEffectiveness**: A brief, one-sentence evaluation of the post's opening line.
        *   **ctaClarity**: A brief, one-sentence assessment of the call-to-action. If there isn't one, suggest one.
        *   **readability**: A one-sentence comment on the post's structure and ease of reading (e.g., use of whitespace, paragraph length).
        *   **keywordRelevance**: A one-sentence analysis of how well the post uses relevant keywords for its topic. Mention if hashtags could be improved.
  `;

  try {
    const response = await ai.models.generateContent({
      model: generativeModel,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.INTEGER, description: "Engagement score from 0-100" },
            strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
            improvements: { type: Type.ARRAY, items: { type: Type.STRING } },
            revisedPost: { type: Type.STRING, description: "The fully rewritten post." },
            detailedAnalysis: {
              type: Type.OBJECT,
              properties: {
                hookEffectiveness: { type: Type.STRING, description: "Evaluation of the opening line." },
                ctaClarity: { type: Type.STRING, description: "Assessment of the call-to-action." },
                readability: { type: Type.STRING, description: "Comment on structure and ease of reading." },
                keywordRelevance: { type: Type.STRING, description: "Analysis of keyword and hashtag usage." },
              },
              required: ["hookEffectiveness", "ctaClarity", "readability", "keywordRelevance"],
            },
          },
          required: ["score", "strengths", "improvements", "revisedPost", "detailedAnalysis"],
        },
      },
    });
    
    const jsonText = response.text.trim();
    const analysisResult: PostAnalysisData = JSON.parse(jsonText);
    return analysisResult;

  } catch (error) {
    console.error("Error analyzing content:", error);
    throw new Error("Failed to analyze the LinkedIn post. Please check your input and try again.");
  }
}